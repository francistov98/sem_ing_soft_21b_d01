<?php include("template/cabecera.php");?>

        <div class="jumbotron text-center">
            <h1 class="display-3">Binevenido al sitio bibliotecario</h1>
            <p class="lead">Consulta de libros</p>
            <hr class="my-2">

            <img whidth="500" src="imagenes/Logo.png" class="img-thumbnail rounded mx-auto d-block" />

            <p>More info</p>
            <p class="lead">
                <a class="btn btn-primary btn-lg" href="productos.php" role="button">Ver libros disponibles</a>
            </p>
        </div>

<?php include("template/pie.php"); ?>